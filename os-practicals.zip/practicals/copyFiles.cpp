#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<unistd.h>
#include<fcntl.h>
using namespace std;
int main(int argc, char *argv[])
{
char ch;
int f1, f2;
f1=open(argv[1], O_RDONLY);
if(f1==-1)
{
cout<<"error in opening the file"<<endl;
close(f1);
exit(1);
}
f2=open(argv[2], O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
while(read(f1, &ch, 1))
{
write(f2, &ch, 1);
}
cout<<"successfully copied contents of file 1 into file 2";
close(f1);
close(f2);
}