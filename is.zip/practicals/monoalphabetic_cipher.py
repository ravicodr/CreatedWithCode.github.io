import string

# Define the mapping for monoalphabetic substitution
def create_substitution_key(key):
    alphabet = string.ascii_lowercase
    substitution_key = {}
    for i in range(26):
        substitution_key[alphabet[i]] = key[i]
    return substitution_key

# Encrypt function using monoalphabetic substitution
def encrypt(content, key):
    encrypted = ""
    substitution_key = create_substitution_key(key)
    for letter in content:
        if letter.lower() in substitution_key:
            encrypted += substitution_key[letter.lower()]
        else:
            encrypted += letter
    return encrypted

# Decrypt function (not needed for monoalphabetic substitution)
def decrypt(content, key):
    # Since monoalphabetic substitution doesn't involve a reversible process,
    # decryption is not straightforward without the original key.
    return "Decryption not possible for monoalphabetic substitution."

if __name__ == "__main__":
    msg = input("Enter Message To Be Encrypted: ")
    key = input("Enter the substitution key (26 unique alphabets): ")
    
    if len(key) != 26 or not key.isalpha():
        print("Invalid key. Please enter 26 unique alphabets.")
    else:
        encryptedMsg = encrypt(msg, key)
        print("Encrypted Message:", encryptedMsg)
