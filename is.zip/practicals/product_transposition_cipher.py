import string

def columnar_transposition_encrypt(text, key):
    key_order = sorted(range(len(key)), key=lambda x: key[x])
    num_cols = len(key)
    num_rows = len(text) // len(key) + (1 if len(text) % len(key) != 0 else 0)
    matrix = [[' ' for _ in range(num_cols)] for _ in range(num_rows)]
    for i, char in enumerate(text):
        matrix[i // num_cols][i % num_cols] = char
    encrypted_text = ''
    for col in key_order:
        for row in range(num_rows):
            encrypted_text += matrix[row][col]
    return encrypted_text

def caesar_cipher_encrypt(text, shift):
    encrypted_text = ''
    for char in text:
        if char.isalpha():
            if char.islower():
                encrypted_text += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            else:
                encrypted_text += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        else:
            encrypted_text += char
    return encrypted_text

def product_cipher_encrypt(text, transposition_key, caesar_shift):
    transposed_text = columnar_transposition_encrypt(text, transposition_key)
    encrypted_text = caesar_cipher_encrypt(transposed_text, caesar_shift)
    return encrypted_text

if __name__ == "__main__":
    text = input("Enter Message To Be Encrypted: ")
    transposition_key = input("Enter the columnar transposition key (e.g., '3124'): ")
    caesar_shift = int(input("Enter the Caesar cipher shift: "))

    encrypted_msg = product_cipher_encrypt(text, transposition_key, caesar_shift)
    print("Encrypted Message:", encrypted_msg)
