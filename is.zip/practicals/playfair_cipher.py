import string

# Generate Playfair matrix
def generate_playfair_matrix(key):
    key = key.lower().replace(" ", "")
    alphabet = string.ascii_lowercase.replace("j", "")
    key += alphabet
    matrix = [key[i:i+5] for i in range(0, 25, 5)]
    return matrix

# Encrypt function using Playfair cipher
def encrypt(content, key):
    content = content.lower().replace("j", "i").replace(" ", "")
    matrix = generate_playfair_matrix(key)
    encrypted = ""
    for i in range(0, len(content), 2):
        pair = content[i:i+2]
        row1, col1 = divmod(matrix.index(pair[0]), 5)
        row2, col2 = divmod(matrix.index(pair[1]), 5)
        if col1 == col2:
            encrypted += matrix[(row1 + 1) % 5][col1]
            encrypted += matrix[(row2 + 1) % 5][col2]
        elif row1 == row2:
            encrypted += matrix[row1][(col1 + 1) % 5]
            encrypted += matrix[row2][(col2 + 1) % 5]
        else:
            encrypted += matrix[row1][col2]
            encrypted += matrix[row2][col1]
    return encrypted.upper()

# Decrypt function using Playfair cipher
def decrypt(content, key):
    matrix = generate_playfair_matrix(key)
    decrypted = ""
    for i in range(0, len(content), 2):
        pair = content[i:i+2].lower()
        row1, col1 = divmod(matrix.index(pair[0]), 5)
        row2, col2 = divmod(matrix.index(pair[1]), 5)
        if col1 == col2:
            decrypted += matrix[(row1 - 1) % 5][col1]
            decrypted += matrix[(row2 - 1) % 5][col2]
        elif row1 == row2:
            decrypted += matrix[row1][(col1 - 1) % 5]
            decrypted += matrix[row2][(col2 - 1) % 5]
        else:
            decrypted += matrix[row1][col2]
            decrypted += matrix[row2][col1]
    return decrypted.replace("x", "")

if __name__ == "__main__":
    msg = input("Enter Message To Be Encrypted: ")
    key = input("Enter the Playfair key: ")
    
    encryptedMsg = encrypt(msg, key)
    print("Encrypted Message:", encryptedMsg)
    
    decryptedMsg = decrypt(encryptedMsg, key)
    print("Decrypted Message:", decryptedMsg)
