import string

def encrypt(content, key):
    encrypted = ""
    for letter in content:
        if letter.isalpha():
            is_upper = letter.isupper()
            letter = letter.lower()
            idx = (string.ascii_lowercase.index(letter) + key) % 26
            encrypted += string.ascii_uppercase[idx] if is_upper else string.ascii_lowercase[idx]
        else:
            encrypted += letter
    return encrypted

def decrypt(content, key):
    decrypted = ""
    for letter in content:
        if letter.isalpha():
            is_upper = letter.isupper()
            letter = letter.lower()
            idx = (string.ascii_lowercase.index(letter) - key) % 26
            decrypted += string.ascii_uppercase[idx] if is_upper else string.ascii_lowercase[idx]
        else:
            decrypted += letter
    return decrypted

if __name__ == "__main__":
    msg = input("Enter Message To Be Encrypted: ")
    while True:
        try:
            key = int(input("Enter Key For Caesar Cipher: "))
            break
        except ValueError:
            print("Enter a valid integer key!")

    encrypted_msg = encrypt(msg, key)
    print("Encrypted Message:", encrypted_msg)
    
    decrypted_msg = decrypt(encrypted_msg, key)
    print("Decrypted Message:", decrypted_msg)
