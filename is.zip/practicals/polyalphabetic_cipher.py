import string

# Generate Vigenère table
def generate_vigenere_table():
    table = {}
    alphabet = string.ascii_lowercase
    for i in range(26):
        shifted_alphabet = alphabet[i:] + alphabet[:i]
        table[alphabet[i]] = shifted_alphabet
    return table

# Encrypt function using Vigenère cipher
def encrypt(content, key):
    encrypted = ""
    table = generate_vigenere_table()
    key_length = len(key)
    key = key.lower()
    for i, letter in enumerate(content):
        if letter.isalpha():
            shift = ord(key[i % key_length]) - ord('a')
            if letter.isupper():
                encrypted += table[key[i % key_length].lower()][ord(letter.lower()) - ord('a')].upper()
            else:
                encrypted += table[key[i % key_length]][ord(letter) - ord('a')]
        else:
            encrypted += letter
    return encrypted

# Decrypt function using Vigenère cipher
def decrypt(content, key):
    decrypted = ""
    table = generate_vigenere_table()
    key_length = len(key)
    key = key.lower()
    for i, letter in enumerate(content):
        if letter.isalpha():
            shift = ord(key[i % key_length]) - ord('a')
            if letter.isupper():
                decrypted += chr((ord(table[key[i % key_length].lower()][ord(letter.lower()) - ord('a')]) - shift - ord('a')) % 26 + ord('A'))
            else:
                decrypted += chr((ord(table[key[i % key_length]][ord(letter) - ord('a')]) - shift - ord('a')) % 26 + ord('a'))
        else:
            decrypted += letter
    return decrypted

if __name__ == "__main__":
    msg = input("Enter Message To Be Encrypted: ")
    key = input("Enter the Vigenère key: ")
    
    encryptedMsg = encrypt(msg, key)
    print("Encrypted Message:", encryptedMsg)
    
    decryptedMsg = decrypt(encryptedMsg, key)
    print("Decrypted Message:", decryptedMsg)
