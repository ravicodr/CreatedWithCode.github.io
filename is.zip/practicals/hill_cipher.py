import string

# Generate matrix key
def generate_key_matrix(key):
    key = key.lower().replace(" ", "")
    n = int(len(key) ** 0.5)
    key_matrix = [[ord(char) - ord('a') for char in key[i:i+n]] for i in range(0, len(key), n)]
    return key_matrix

# Generate inverse key matrix
def generate_inverse_key_matrix(key_matrix):
    det = key_matrix[0][0] * key_matrix[1][1] - key_matrix[0][1] * key_matrix[1][0]
    det_inv = 0
    for i in range(26):
        if (det * i) % 26 == 1:
            det_inv = i
            break
    inv_key_matrix = [[(key_matrix[1][1] * det_inv) % 26, (-key_matrix[0][1] * det_inv) % 26],
                      [(-key_matrix[1][0] * det_inv) % 26, (key_matrix[0][0] * det_inv) % 26]]
    return inv_key_matrix

# Encrypt function using Hill cipher
def encrypt(content, key):
    content = content.lower().replace(" ", "")
    n = int(len(key) ** 0.5)
    key_matrix = generate_key_matrix(key)
    result = ""
    while len(content) % n != 0:
        content += 'x'  # Padding if necessary
    for i in range(0, len(content), n):
        chunk = [[ord(char) - ord('a')] for char in content[i:i+n]]
        encrypted_chunk = [[sum(key_matrix[j][k] * chunk[k][0] for k in range(n)) % 26] for j in range(n)]
        result += ''.join([chr(num + ord('a')) for sublist in encrypted_chunk for num in sublist])
    return result.upper()

# Decrypt function using Hill cipher
def decrypt(content, key):
    n = int(len(key) ** 0.5)
    key_matrix = generate_key_matrix(key)
    inv_key_matrix = generate_inverse_key_matrix(key_matrix)
    result = ""
    for i in range(0, len(content), n):
        chunk = [[ord(char) - ord('a')] for char in content[i:i+n]]
        decrypted_chunk = [[sum(inv_key_matrix[j][k] * chunk[k][0] for k in range(n)) % 26] for j in range(n)]
        result += ''.join([chr(num + ord('a')) for sublist in decrypted_chunk for num in sublist])
    return result.replace("x", "")

if __name__ == "__main__":
    msg = input("Enter Message To Be Encrypted: ")
    key = input("Enter the Hill cipher key (4 characters): ")
    
    encryptedMsg = encrypt(msg, key)
    print("Encrypted Message:", encryptedMsg)
    
    decryptedMsg = decrypt(encryptedMsg, key)
    print("Decrypted Message:", decryptedMsg)
