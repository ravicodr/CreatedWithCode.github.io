def encrypt_rail_fence(text, rails):
    fence = [[] for _ in range(rails)]
    rail = 0
    direction = 1

    for char in text:
        fence[rail].append(char)
        rail += direction
        if rail == rails - 1 or rail == 0:
            direction = -direction

    encrypted_text = ''
    for rail in fence:
        encrypted_text += ''.join(rail)

    return encrypted_text

def decrypt_rail_fence(text, rails):
    fence = [[] for _ in range(rails)]
    rail = 0
    direction = 1

    for char in text:
        fence[rail].append(None)
        rail += direction
        if rail == rails - 1 or rail == 0:
            direction = -direction

    index = 0
    for i in range(rails):
        for j in range(len(fence[i])):
            fence[i][j] = text[index]
            index += 1

    rail = 0
    direction = 1
    decrypted_text = ''
    for _ in range(len(text)):
        decrypted_text += fence[rail].pop(0)
        rail += direction
        if rail == rails - 1 or rail == 0:
            direction = -direction

    return decrypted_text

if __name__ == "__main__":
    text = input("Enter Message To Be Encrypted: ")
    rails = int(input("Enter the number of rails: "))

    encrypted_msg = encrypt_rail_fence(text, rails)
    print("Encrypted Message:", encrypted_msg)

    decrypted_msg = decrypt_rail_fence(encrypted_msg, rails)
    print("Decrypted Message:", decrypted_msg)
