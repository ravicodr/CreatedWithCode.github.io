def encrypt_row_transposition(text, key):
    key_order = sorted(range(1, len(key) + 1), key=lambda x: key[x - 1])
    num_rows = len(text) // len(key) + (1 if len(text) % len(key) != 0 else 0)
    matrix = [[' ' for _ in range(len(key))] for _ in range(num_rows)]
    for i, char in enumerate(text):
        matrix[i // len(key)][i % len(key)] = char
    encrypted_text = ''
    for row in matrix:
        for col in key_order:
            encrypted_text += row[col - 1]
    return encrypted_text

def decrypt_row_transposition(text, key):
    key_order = sorted(range(1, len(key) + 1), key=lambda x: key[x - 1])
    num_rows = len(text) // len(key) + (1 if len(text) % len(key) != 0 else 0)
    num_cols = len(key)
    # Calculate the number of elements in the last row
    num_elements_last_row = len(text) % len(key) if len(text) % len(key) != 0 else len(key)
    # Calculate the number of elements in other rows
    num_elements_other_rows = len(key) - num_elements_last_row

    # Calculate the number of elements in each row
    elements_in_each_row = [num_elements_last_row] * num_rows
    elements_in_each_row[:-1] = [num_elements_other_rows] * (num_rows - 1)

    # Calculate the start index for each row
    start_index_each_row = [0]
    for i in range(num_rows - 1):
        start_index_each_row.append(start_index_each_row[-1] + elements_in_each_row[i])

    # Reorder the key_order based on the key
    new_key_order = sorted(range(1, len(key) + 1), key=lambda x: key_order.index(x))
    
    matrix = [[' ' for _ in range(num_cols)] for _ in range(num_rows)]
    index = 0
    for col in new_key_order:
        for row in range(num_rows):
            if index >= len(text):
                break
            matrix[row][col - 1] = text[index]
            index += 1
    
    decrypted_text = ''
    for row in range(num_rows):
        for col in range(num_cols):
            decrypted_text += matrix[row][col]
    return decrypted_text

if __name__ == "__main__":
    text = input("Enter Message To Be Encrypted: ")
    key = input("Enter the key (permutation of numbers 1 to n): ")

    encrypted_msg = encrypt_row_transposition(text, key)
    print("Encrypted Message:", encrypted_msg)

    decrypted_msg = decrypt_row_transposition(encrypted_msg, key)
    print("Decrypted Message:", decrypted_msg)
