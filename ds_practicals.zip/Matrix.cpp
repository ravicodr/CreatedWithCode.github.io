#include <iostream>
using namespace std;

class DM
{
	int *arr;
	int size;
	public:
		DM(int x)
		{
		size=x;
		arr= new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=0;
		}
		}
		
		int	get(int i, int j)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
				
			}
			if(i==j)
			{
				return arr[i-1];
			}
			return 0;
		
		}
		
		void set(int i, int j, int x)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
				exit(0);
			}
			if(i==j)
			{
				arr[i-1]=x;
			}
		
		}
		
		void display()
		{
			for(int i=1;i<=size;i++)
			{
				for(int j=1;j<=size;j++)
				{
					cout << get(i,j) << " ";
				}
				cout<<endl;
			}
		}
};
class TriDM
{
	int *arr;
	int size;
	int n;
	public:
		TriDM(int x)
		{
		n=x;
		size=3*n-2;
		arr= new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=0;
		}
		}
		
		int	get(int i, int j)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
				
			}
			if(i-j==1)
			{
				return arr[i-2];
			}
			
			if(i==j)
			{
				return arr[n+i-2];
			}
			
			if(i-j==-1)
			{
				return arr[2*n+i-1];
			}
			return 0;
		
		}
		
		void set(int i, int j, int x)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
				exit(0);
			}
			if(i-j==1)
			{
			   arr[i-2]=x;
			}
			
			if(i==j)
			{
				arr[n+i-2]=x;
			}
			
			if(i-j==-1)
			{
				arr[2*n+i-1]=x;
			}
			 
		
		}
		void display()
		{
			for(int i=0;i<n;i++)
			{
				for(int j=0; j<n;j++)
				{
					cout << get(i+1,j+1) << " ";
				}
				cout<<endl;
			}
		}
};


class LowerTriangular
{
	int *arr;
	int size;
	int n;
	public:
		LowerTriangular(int x)
		{
		n=x;
		size= (n*(n+1))/2;
		arr= new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=0;
		}
		}
		
		int	get(int i, int j)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
			}
			if(j<=i)
			{
				return arr[((i-1)*i/2)+ j-1];
			}
			return 0;
		
		}
		
		void set(int i, int j, int x)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
			}
			if(j<=i)
			{
				arr[((i-1)*i/2)+ j-1] = x;
			}
			
		}
		void display()
		{
			for(int i=0;i<n;i++)
			{
				for(int j=0; j<n;j++)
				{
					cout << get(i+1,j+1) << " ";
				}
				cout<<endl;
			}
		}
};

class UpperTriangular
{
	int *arr;
	int size;
	int n;
	public:
		UpperTriangular(int x)
		{
		n=x;
		size= (n*(n+1))/2;
		arr= new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=0;
		}
		}
		
		int	get(int i, int j)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
			}
			if(i<=j)
			{
				return arr[((j-1)*j/2)+ i-1];
			}
			return 0;
		
		}
		
		void set(int i, int j, int x)
		{
			if(i<0 || j<0 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
			}
			if(i<=j)
			{
				arr[((j-1)*j/2)+ i-1] = x;
			}
			
		}
		void display()
		{
			for(int i=0;i<n;i++)
			{
				for(int j=0; j<n;j++)
				{
					cout << get(i+1,j+1) << " ";
				}
				cout<<endl;
			}
		}
};

class Symmetric
{
	int *arr;
	int size;
	int n;
	public:
		Symmetric(int x)
		{
		n=x;
		size= (n*(n+1))/2;
		arr= new int[size];
		for(int i=0;i<size;i++)
		{
			arr[i]=0;
		}
		}
		
		int	get(int i, int j)
		{
			if(i<1 || j<1 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
			}
			if(i<=j)
				return arr[n*i-((i-1)*i)/2 +j-i];
			else
				return arr[j*n-((j-1)*j)/2+i-j];
			
		
		}
		
		void set(int i, int j, int x)
		{
			if(i<1 || j<1 || i>size || j>size)
			{
				cout<<"please enter correct value of i and j"<<endl;
			}
			if(i<=j)
				arr[n*i-((i-1)*i)/2 +j-i]=x;
			else 
				arr[j*n-((j-1)*j)/2+i-j]=x;
			
		}
		void display()
		{
			for(int i=1;i<n;i++)
			{
				for(int j=1;j<n;j++)
				{
					cout << get(i+1,j+1) << " ";
				}
				cout<<endl;
			}
		}
};

int main() 
{
	int choice;
	
	cout<<"1. Diagonal matrix\n 2. TriDiagonal Matrix\n 3. Lower Triangular Matrix\n 4. Upper Triangular matrix\n 5. Symmetric matrix"<<endl;
	cin>>choice;
	
	switch(choice)
		{
			case 1:
				{
					int n;
					cout << "Enter the size of matrix: ";
					cin >>n;
					DM dumDUM(n);
					while (true) {
						cout << "1. Set Element\n2.Get Element\n3.Display\n4.Exit\n";
						int s2;
						cin >> s2;
						
						switch (s2)
						{
							case 1:
								{
									int i,j,x;
									cout << "Enter row and col: ";
									cin >> i >> j;
									cout << "Enter element to insert: ";
									cin >> x;
									
									dumDUM.set(i,j,x);
									break;
								}
								
							case 2:
							{
								int i,j;
								cout << "Enter row and col: ";
								cin >> i >> j;
							
								cout << dumDUM.get(i,j);
								break;
							}
							case 3:
							{
								dumDUM.display();
								break;
							}
							case 4:
							{
								break;
							}
							default:
								break;
						}
					}
				}
				
			case 2:
			{
				int n;
				cout << "Enter the size of matrix: ";
				cin >>n;
				TriDM dumDUM(n);
				while (true) {
					cout << "1. Set Element\n2.Get Element\n3.Display\n4.Exit\n";
					int s2;
					cin >> s2;
					
					switch (s2)
					{
						case 1:
							{
								int i,j,x;
								cout << "Enter row and col: ";
								cin >> i >> j;
								cout << "Enter element to insert: ";
								cin >> x;
								
								dumDUM.set(i,j,x);
								break;
							}
							
						case 2:
						{
							int i,j;
							cout << "Enter row and col: ";
							cin >> i >> j;
						
							cout << dumDUM.get(i,j);
							break;
						}
						case 3:
						{
							dumDUM.display();
							break;
						}
						case 4:
						{
							break;
						}
						default:
							break;
					}
				}
				break;
			}
			
		
		
		case 3:
			{
				int n;
				cout << "Enter the size of matrix: ";
				cin >>n;
				LowerTriangular dumDUM(n);
				while (true) {
					cout << "1. Set Element\n2.Get Element\n3.Display\n4.Exit\n";
					int s2;
					cin >> s2;
					
					switch (s2)
					{
						case 1:
							{
								int i,j,x;
								cout << "Enter row and col: ";
								cin >> i >> j;
								cout << "Enter element to insert: ";
								cin >> x;
								
								dumDUM.set(i,j,x);
								break;
							}
							
						case 2:
						{
							int i,j;
							cout << "Enter row and col: ";
							cin >> i >> j;
						
							cout << dumDUM.get(i,j);
							break;
						}
						case 3:
						{
							dumDUM.display();
							break;
						}
						case 4:
						{
							break;
						}
						default:
							break;
					}
				}
				break;
			}
			
		
		
		case 4:
			{
				int n;
				cout << "Enter the size of matrix: ";
				cin >>n;
				UpperTriangular dumDUM(n);
				while (true) {
					cout << "1. Set Element\n2.Get Element\n3.Display\n4.Exit\n";
					int s2;
					cin >> s2;
					
					switch (s2)
					{
						case 1:
							{
								int i,j,x;
								cout << "Enter row and col: ";
								cin >> i >> j;
								cout << "Enter element to insert: ";
								cin >> x;
								
								dumDUM.set(i,j,x);
								break;
							}
							
						case 2:
						{
							int i,j;
							cout << "Enter row and col: ";
							cin >> i >> j;
						
							cout << dumDUM.get(i,j);
							break;
						}
						case 3:
						{
							dumDUM.display();
							break;
						}
						case 4:
						{
							break;
						}
						default:
							break;
					}
				}
				break;
			}
			
		
		
		case 5:
			{
				int n;
				cout << "Enter the size of matrix: ";
				cin >>n;
				Symmetric dumDUM(n);
				while (true) {
					cout << "1. Set Element\n2.Get Element\n3.Display\n4.Exit\n";
					int s2;
					cin >> s2;
					
					switch (s2)
					{
						case 1:
							{
								int i,j,x;
								cout << "Enter row and col: ";
								cin >> i >> j;
								cout << "Enter element to insert: ";
								cin >> x;
								
								dumDUM.set(i,j,x);
								break;
							}
							
						case 2:
						{
							int i,j;
							cout << "Enter row and col: ";
							cin >> i >> j;
						
							cout << dumDUM.get(i,j);
							break;
						}
						case 3:
						{
							dumDUM.display();
							break;
						}
						case 4:
						{
							break;
						}
						default:
							break;
					}
				}
				break;
			}
			
		}
	}
	
	


