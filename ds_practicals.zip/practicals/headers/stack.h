#include"sll.h"
#include<stdexcept>

using namespace std;

template<typename T>
class Stack{
private:
    list<T> l;
    int s;			// current size
public:
    Stack(){
	s=0;
	//n=10;
    }

    void push(T el){
	l.insertAtHead(el);
	s++;
    }
    void pop(){
	if(s==0)
	    cout << "\n\tStackUnderFlow..." << endl;
	else{
	    l.removeAtHead();
	    s--;
	}
    }

    T topEl(){
	if(s==0){
	    throw "\n\tStack is empty. No top element available" ;
	}
	T el = l.removeAtHead();
	l.insertAtHead(el);
	return el;
    }

    void clear(){
	s=0;
	while(s>0){
	    l.removeAtHead();
	}
    }

    bool isEmpty(){
	return s==0;
    }

    int size(){
	return s;
    }

    void displayStack(){
	if(s==0)
	    cout << "Stack Empty.." << endl;
	else
	    l.display();
    }
    
};

