// doubly linked list header for deque
// *self note: all functions names, vars,etc are in small because of cp.. use properly

#include<iostream>

using namespace std;

template<typename t>
class node
{
public:
    t data;
    node* next;
    node* prev;
    node(){
	next = NULL;
	prev = NULL;
    }
    node(t x,node* nptr,node* pptr){
	data = x;
	next = nptr;
	prev = pptr;
    }
};

template<typename t>
class list
{
private:
    node<t> *head;
    node<t> *tail;
public:
    list(){
	head = new node<t>();
	tail = new node<t>();
	head->next = tail;
	tail->prev = head;
    }

    ~list(){
	node<t> *p;
	while(!isempty()){
	    p = head->next;
	    delete head;
	    head = p;
	}
    }

    bool isempty(){
	return head->next == tail;
    }

    int size(){
	node<t> *temp = head->next;
	int s = 0;
	while(temp!=tail){
	    temp = temp->next;
	    s++;
	}
	return s;
    }

    t frontEl(){
	if(isempty())
	    throw "Cant access front el, list is empty";
	return head->next->data;

    }

    t backEl(){
	if(isempty())
	    throw "Cant access back el, list is empty";
	return tail->prev;

    }

    void insertathead(t el){
	node<t> *temp = new node<t>(el,head->next,head);
	temp->next->prev = temp;
	head->next = temp;
	//cout << "temp = " << temp << "\nhead = " << head << "\ntail = " << tail;
	//cout << "\nhead->next = " << head->next << "\ntail->prev = " << tail->prev << endl;
    }

    void insertatposition(t el,int pos){
	node<t> *temp = head->next;
	int p = 1;
	if(pos == 1){
	    insertathead(el);
	}
	else if(pos<1){
	    cout << "cant add position cant be less than 1.." << endl;
	}
	else if(pos>size()){
	    cout << "cant add, position cant be greater than size (" << size() << ")." << endl;
	}
	else{
	    while(p<pos){
		temp = temp->next;	
		p++;
	    }
	    
	    temp->prev->next = new node<t>(el,temp,temp->prev);
	}
    }

    void insertattail(t el){
	node<t> *temp = new node<t>(el,tail,tail->prev);
	temp->prev->next = temp;
	tail->prev = temp;
	//cout << "temp = " << temp << "\nhead = " << head << "\ntail = " << tail;
	//cout << "\nhead->next = " << head->next << "\ntail->prev = " << tail->prev << endl;
    }

    void removeathead(){
	if(isempty()){
	    cout << "cant remove. list is empty" << endl;
	}
	else{
	    node<t> *temp = head->next;
	    head->next = temp->next;
	    temp->next->prev = head;
	    delete temp;
	}
    }

    void removeatposition(int pos){
	node<t> *temp = head->next;
	int p = 1;
	if(isempty()){
	    cout << "cant remove, list empty." << endl;
	}
	else if(pos==1){
	    removeathead();
	}
	else if(pos<1){
	    cout << "cant remove, position cant be less than 1" << endl;
	}
	else if(pos>size()){
	    cout << "cant remove. position cant be greater than size (" << size() << ")." <<endl;
	}
	else{
	    node<t> *temp = head->next;
	    while(p<pos){
		temp = temp->next;
		p++;
	    }
	    temp->prev->next = temp->next;
	    temp->next->prev = temp->prev;
	    delete temp;
	}
    }

    void removeattail(){
	if(isempty()){
	    cout << "cant remove, list is empty." << endl;
	}
	else{
	    node<t> *temp = tail->prev;
	    temp->prev->next = tail;
	    tail->prev = temp->prev;
	    delete temp;
	}
    }

    node<t> * searchel(t el){
	node<t> *temp = head->next;
	if(isempty()){
	    cout << "cant search, list empty" << endl;
	}
	else{
	    while(temp != tail){
		if(temp->data==el)
		    return temp;
		temp = temp->next;
	    }
	}
	return NULL;
    }

       void display(){
	node<int> *temp = head->next;
	if(isempty())
	    cout << "--empty--" << endl;
	else{
	    while(temp != tail){
		cout << temp->data << " | ";
		temp = temp->next;
	    }
	}
	cout << endl;
    }

    
    
};
