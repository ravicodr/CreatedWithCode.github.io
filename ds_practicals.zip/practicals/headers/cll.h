#include<iostream>
#include<stdexcept>
using namespace std;

template<typename T>
class cllNode{
public:
    T data;
    cllNode<T>* next;
};

template<typename T>
class cll{
private:
    cllNode<T>* cursor;
public:
    cll(){
	cursor = NULL;
    }
    ~cll(){
	while(!isEmpty()){
	    cllNode<T>* temp=cursor->next;
	    if(temp==cursor)
		cursor=NULL;
	    else{
		cursor->next = temp->next;
	    }
	    delete temp;
	}
    }

    bool isEmpty(){
	return cursor==NULL;
    }

    void advance(){
	if(!isEmpty())
	    cursor = cursor->next;
    }

    T front(){		    // Front element, i.e after cursor
	try{
	    if(isEmpty())
		throw "Queue is empty no front element";
	}
	catch(const char* ch){
	    cout << ch << endl;
	}
	return cursor->next->data;
    }

    T back(){			    // Back element that is cursor's data
	try{
	    if(isEmpty())
		throw "Queue is empty no front element";
	}
	catch(const char* ch){
	    cout << ch << endl;
	}
	return cursor->data;

    }

    void addFront(T el){		    // Add to front (after cursor)
	cllNode<T> *temp = new cllNode<T>;
	temp->data= el;
	if(cursor==NULL){
	    temp->next = temp;
	    cursor = temp;
	}
	else{
	    temp->next = cursor->next;
	    cursor->next = temp;
	}
    }

    void removeFront(){		    // remove front el
	if(isEmpty()){
	    cout << "list already empty." << endl;
	}
	else{
	    cllNode<T> *temp = cursor->next;
	    if(temp==cursor)
		cursor = NULL;
	    else
		cursor->next = temp->next;
	    delete temp;
	}

    }

    void addBack(T el){
	cllNode<T> *temp = new cllNode<T>;
	temp->data= el;
	if(cursor==NULL){
	    temp->next = temp;
	    cursor = temp;
	}
	else{
	    cllNode<T> *temp2 = cursor->next;
	    while(!temp2->next==cursor){
		temp2 = temp2->next;
	    }
	    temp2->next = temp;
	    temp->next = cursor;
	}

    }

    void clear(){
	    while(!isEmpty()){
		cllNode<T>* temp=cursor->next;
		if(temp==cursor)
		    cursor=NULL;
		else{
		    cursor->next = temp->next;
		}
		delete temp;
	    }

	}
};


