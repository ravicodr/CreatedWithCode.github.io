#include"cll.h"
#include<stdexcept>

using namespace std;

template<typename T>
class queue{
private:
   cll<T> q;
   int s;	    // current size
public:
   queue(){
	s=0;
   }
   int size(){
       return s;
   }
   T frontEl(){
       if(s==0)
	   throw "ERROR: Queue empty. Cant return!" ;
       return q.front();
   }
   bool isEmpty(){
       return s==0;
   }
   
   void enqueue(T el){
	   q.addFront(el);
	   q.advance();
	   s++;
   }

   void dequeue(){
       if(s==0){
       cout << "ERROR: Queue empty. Cant remove!";
       }
       else{
	   q.removeFront();
	   s--;
       }
   }

   void display(){
       if(s==0)
	   cout << "--Empty--" << endl;
       else{
	   cout << endl;
	   for(int i=0;i<s;i++)
	       cout << "-----";
	   cout << endl;
	   for(int i=0;i<s;i++){
	       cout << q.front() << " | " ;
	       q.advance();
	   }
	   cout << endl;
	   for(int i=0;i<s;i++)
	       cout << "-----";
	   cout << endl;
       }
   }

   void clear(){
       q.clear();
       s=0;
   }

};

