#include<iostream>
#include<stdexcept>

using namespace std;

template<typename T>
class sNode{				    //sNode class, represents each node, has data and pointer to next node
public:
    T data;
    sNode* next;
    sNode(){
	next = 0;			    //pointer for last node is taken as 0
    }
    sNode(T num,sNode* nptr=0){
	next = nptr;
	data = num;
    }
};

template<class T>
class list{				    // List class
public:
    sNode<T> *head;
    list(){				    // constructor and destructor
	head = 0;
    }
    ~list(){
	sNode<T> *p;
	while(!isEmpty()){
	    p = head->next;
	    delete head;
	    head = p;
	}
    }

    bool isEmpty(){			    // if head doesnt points to any address, list is empty
	return head==0;
    }

    int size(){
	sNode<T> *temp = head;
	if(isEmpty())
	    return 0;
	int s=1;
	for(temp = head;temp->next!=0;temp = temp->next)
	    s++;
	return s;
    }

    void insertAtHead(T el){			// (i)
	head = new sNode<T>(el,head);		// point head to new node, while assigning 'next' of new node as previous head
    }

    void insertAtPosition(T el,int pos){	// (ii)
	sNode<T> *temp = head;			// temp pointer starts at head
	int count = 1;
	if(pos==1)
	    insertAtHead(el);
	else if(isEmpty())
	    cout << "\nList is empty, cant add at " << pos << endl;
	else if(pos<=0 || pos>size())
	    cout << "\nposition out of range, cant be <=0 or >size. (size=" << size() << ")" << endl;
	else{
	    while(count<pos-1){			 // loop till temp reaches position before which we have to add e.g if pos = 4
		temp = temp->next;			 // loop will end after 2 times, reaching 3
		count++;
	    }
	    temp->next = new sNode<T>(el,temp->next);	// link previous node (pos-1, eg 3) to new node, that will be 4th while assigning
	}					// while pointing next of new node to next of previous node. i.e next of 3 to next of 4

    }

    T removeAtHead(){				// (iii)
	T el = head->data;			// store data being removed to return it later
	sNode<T>* temp = head;			// assign head ptr to temp
	if(head->next==0){			 // if head is only element (i.e head->next==0), set Head as 0
	    head = 0;
	}
	else{
	    head = head->next;			 // else assign head as next node
	    delete temp;				
	}
	return el;				// delete temp and return removed data
    }

    T removeAtPosition(int pos){
	sNode<T> *temp = head;
	T el;
	int count = 1;
	if(pos==1)
	    el = removeAtHead();
	else if(isEmpty()){
	    cout << "\nList is empty, cant remove at " << pos << endl;
	    throw range_error("\nCant remove from empty list");
	}
	else if(pos<=0 || pos>size()){
	    cout << "\nposition out of range, cant be <=0 or >size. (size=" << size() << ")" << endl;
	    throw range_error("out of range");
	}
	else{
	    while(count<pos-1){
		temp = temp->next;
		count++;
	    }
	    sNode<T> *temp1 = temp->next;   //to be removed
	    temp->next = temp1->next;
	    el = temp1->data;
	    delete temp1;
	}
	return el;
    }

    void insertAtTail(T el){
	sNode<T> *temp;
	temp = head;
	if(isEmpty())
	    insertAtHead(el);
	else{
	    while(temp->next!=0){
		temp = temp->next;
	    }
	    temp->next = new sNode<T>(el);
	}
    }

   sNode<T>*  searchEl(T el){
       sNode<T>* temp;
       temp = head;
       while(temp!=0){
	   if(temp->data == el)
	       return temp;
	   temp = temp->next;
       }
       return NULL;
   }
    
  void concatenate(list &nlist){
      if(isEmpty())
	  cout << "\nfirst list is empty cant concatenate.." << endl;
      else if(nlist.isEmpty())
	  cout << "\nsecond list is empty cant concatenate.." << endl;
      else{
	  sNode<T> *temp = head;
	  while(temp->next!=0){
		temp = temp->next;
	  }
	  temp->next = nlist.head;
      }
  }

   void display(){
       if(isEmpty())
	   cout << "--" << endl;
       else{
	   sNode<T> *temp = head;
	   while(!temp->next==0){
	       cout << temp->data << " ";
	       temp = temp->next;
	   }
	   cout << temp->data << endl;
       }
   }


};

