const http = require('http');
const url = require('url');
const qs = require('querystring');
const mysql = require('mysql');
const fs = require('fs');

const port = 10000;

// Create a MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'itusers',
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);

  if (req.method === 'POST') {
    let body = '';

    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      const data = qs.parse(body);

      if (parsedUrl.pathname === '/signin') {
        // Handle SignIn
        const { username, password } = data;
        signInHandler(username, password, res);
      } else if (parsedUrl.pathname === '/signup') {
        // Handle SignUp
        const { username, password } = data;
        signUpHandler(username, password, res);
      } else {
        // Invalid endpoint
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
      }
    });
  } else {
    // Serve the HTML file
    res.writeHead(200, { 'Content-Type': 'text/html' });
    const htmlContent = fs.readFileSync('index.html', 'utf-8');
    res.end(htmlContent);
  }
});

server.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}/`);
});

// Function to handle SignIn
function signInHandler(username, password, res) {
  const query = 'SELECT * FROM login WHERE username = ? AND password = ?';
  db.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error executing query:', err);
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
    } else {
      if (results.length > 0) {
        // Successful SignIn
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('<h1>Welcome to the Welcome Page!</h1>');
      } else {
        // Invalid credentials
        res.writeHead(401, { 'Content-Type': 'text/plain' });
        res.end('Invalid credentials');
      }
    }
  });
}

// Function to handle SignUp
function signUpHandler(username, password, res) {
  const query = 'INSERT INTO login (username, password) VALUES (?, ?)';
  db.query(query, [username, password], (err) => {
    if (err) {
      console.error('Error executing query:', err);
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Internal Server Error');
    } else {
      // Successful SignUp
      res.writeHead(302, { 'Location': '/index.html' });
      res.end();
    }
  });
}